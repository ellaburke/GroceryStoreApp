package com.example.ca1_grocery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class PaymentActivity extends AppCompatActivity {
    ArrayList<GroceryItems> groceryItems = new ArrayList<>();
    TextView shoppingListContentsTV;
    TextView shoppingListContentsPrice;
    TextView shoppingListTotalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Button completeButton = (Button) findViewById(R.id.completePaymentButton);
        CheckBox cashCheckBox = (CheckBox) findViewById(R.id.cashCheckBox);
        CheckBox cardCheckBox = (CheckBox) findViewById(R.id.cardCheckBox);
        EditText cardNoEditText = (EditText) findViewById(R.id.cardNumberInput);
        EditText cardExpiry = (EditText) findViewById(R.id.cardExpiryDate);
        EditText cardCVC = (EditText) findViewById(R.id.cvcNumber);

        shoppingListContentsTV = (TextView) findViewById(R.id.itemDisplayTextView);
        shoppingListContentsPrice = (TextView) findViewById(R.id.itemPriceDisplay);
        shoppingListTotalPrice = (TextView) findViewById(R.id.displayTotalTextView);

        displayShoppingList();
        cashCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    completeButton.setEnabled(true);
                    cardCheckBox.setEnabled(false);
                    cardNoEditText.setEnabled(false);
                    cardExpiry.setEnabled(false);
                    cardCVC.setEnabled(false);

                } else {
                    completeButton.setEnabled(false);
                    cardCheckBox.setEnabled(true);
                    cardNoEditText.setEnabled(true);
                    cardExpiry.setEnabled(true);
                    cardCVC.setEnabled(true);
                }

            }
        });
        cardCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    completeButton.setEnabled(true);
                    cashCheckBox.setEnabled(false);

                } else {
                    completeButton.setEnabled(false);
                    cashCheckBox.setEnabled(true);
                }

            }
        });
        completeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PaymentActivity.this, "Thank you for shopping at Ella's Supermarket", Toast.LENGTH_LONG).show();
            }
        });

    }


    public void displayShoppingList() {

        String itemNameOutput = "";
        String itemPriceOutput = "";
        double total = 0;

        if (groceryItems.isEmpty()) {
            shoppingListContentsTV.setText("Shopping List is Empty!");
            shoppingListContentsPrice.setText("");
            shoppingListTotalPrice.setText("€0.00");
        } else {
            for (GroceryItems i : groceryItems) {
                itemNameOutput += i.getItemName();
                itemNameOutput += " ";
                itemNameOutput += "\n";
                itemPriceOutput += i.getItemPrice();
                itemPriceOutput += " ";
                itemPriceOutput += "\n";
                total = total+i.getItemPrice();

            }
            shoppingListContentsTV.setText(itemNameOutput);
            shoppingListContentsPrice.setText(itemPriceOutput);
            shoppingListTotalPrice.setText("€"+ String.format("%.2f", total));
        }
    }
}
