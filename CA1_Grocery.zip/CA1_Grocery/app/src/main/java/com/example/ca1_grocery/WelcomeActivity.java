package com.example.ca1_grocery;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class WelcomeActivity extends AppCompatActivity {

    ArrayList<GroceryItems> groceryItems = new ArrayList<>();

    private GroceryItems cocacola = new GroceryItems("Coca-cola", 1.50);
    private GroceryItems milk = new GroceryItems("Milk", 1.95);
    private GroceryItems bread = new GroceryItems("Bread", 2.50);
    private GroceryItems broccoli = new GroceryItems("Broccoli", 0.80);
    private GroceryItems crisps = new GroceryItems("Crisps", 0.99);
    private GroceryItems chicken = new GroceryItems("Chicken", 5.00);

    Button cocacolaAddBtn;
    Button milkAddBtn;
    Button breadAddBtn;
    Button broccoliAddBtn;
    Button crispsAddBtn;
    Button chickenAddBtn;
    Button viewCartBtn;
    Button checkoutBtn;
    Button logoutBtn;
    Button cocacolaDelBtn;
    Button milkDelBtn;
    Button breadDelBtn;
    Button broccoliDelBtn;
    Button crispsDelBtn;
    Button chickenDelBtn;
    Button searchRemoveButton;

    TextView cocacolaTextView;
    TextView milkTextView;
    TextView breadTextView;
    TextView broccoliTextView;
    TextView crispsTextView;
    TextView chickenTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        cocacolaAddBtn = (Button) findViewById(R.id.cocacolaAddButton);
        milkAddBtn = (Button) findViewById(R.id.milkAddButton);
        breadAddBtn = (Button) findViewById(R.id.breadAddButton);
        broccoliAddBtn = (Button) findViewById(R.id.broccoliAddButton);
        crispsAddBtn = (Button) findViewById(R.id.crispsAddButton);
        chickenAddBtn = (Button) findViewById(R.id.chickenAddButton);
        viewCartBtn = (Button) findViewById(R.id.viewCartButton);
        checkoutBtn = (Button) findViewById(R.id.checkoutButton);
        logoutBtn = (Button) findViewById(R.id.logInDiffAccButton);
        cocacolaDelBtn = (Button) findViewById(R.id.cocacolaRemoveButton);
        milkDelBtn = (Button) findViewById(R.id.milkRemoveButton);
        breadDelBtn = (Button) findViewById(R.id.breadRemoveButton);
        broccoliDelBtn = (Button) findViewById(R.id.broccoliRemoveButton);
        crispsDelBtn = (Button) findViewById(R.id.crispsRemoveButton);
        chickenDelBtn = (Button) findViewById(R.id.chickenRemoveButton);
        searchRemoveButton = (Button) findViewById(R.id.itemSearchRemoveButton);

        String username = getIntent().getStringExtra("usernameInput");
        TextView usernameDisplay = (TextView) findViewById(R.id.welcomeUsernameTextView);
        usernameDisplay.setText(username + " Logged In!");
        //updateShoppingCart();

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WelcomeActivity.this.finish();
            }
        });
        cocacolaAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem(cocacola);
            }
        });
        milkAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem(milk);
            }
        });
        breadAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem(bread);
            }
        });
        broccoliAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem(broccoli);
            }
        });
        crispsAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem(crisps);
            }
        });
        chickenAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem(chicken);
            }
        });
        cocacolaDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(cocacola);
            }
        });
        milkDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(milk);
            }
        });
        breadDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(bread);
            }
        });
        broccoliDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(broccoli);
            }
        });
        crispsDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(crisps);
            }
        });
        chickenDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(chicken);
            }
        });
        viewCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String output = "";

                if (groceryItems.isEmpty()) {
                    Toast.makeText(WelcomeActivity.this, "Shopping List is Empty!", Toast.LENGTH_LONG).show();
                } else {
                    for (GroceryItems i : groceryItems) {
                        output += i.getItemName();
                        output += " ";
                        output += i.getItemPrice();
                        output += "\n";
                    }Toast.makeText(WelcomeActivity.this, "Shopping List: \n" + output, Toast.LENGTH_LONG).show();
                }
            }

        });
        searchRemoveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText searchedForItem = (EditText) findViewById(R.id.itemToRemoveEditText);
                String itemToRemove = searchedForItem.getText().toString();

                if(groceryItems.isEmpty())
                    Toast.makeText(WelcomeActivity.this, "Shopping list is empty", Toast.LENGTH_LONG).show();
                else{
                    for(GroceryItems groceryItem: groceryItems) {
                        if (itemToRemove.equalsIgnoreCase(groceryItem.getItemName())) {
                            groceryItems.remove(groceryItem);
                            Toast.makeText(WelcomeActivity.this, groceryItem.getItemName() + " removed from shopping list", Toast.LENGTH_LONG).show();
                        }
                        else {
                            Toast.makeText(WelcomeActivity.this, "There is no " + itemToRemove + " on your shopping list", Toast.LENGTH_LONG).show();
                        }
                    }

                }
            }
        });
        checkoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this, PaymentActivity.class);
                intent.putExtra("groceryList", groceryItems);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id ==R.id.logOut_menu){
            WelcomeActivity.this.finish();
            return true;
        }

        return true;
    }

    public void addItem(GroceryItems groceryItem ){
        if(groceryItems.contains(groceryItem))
            Toast.makeText(WelcomeActivity.this, "You have already added " + groceryItem.getItemName()  + " to your list", Toast.LENGTH_LONG).show();
        else{
            groceryItems.add(groceryItem);
            Toast.makeText(WelcomeActivity.this, groceryItem.getItemName() + " has been added to your shopping list", Toast.LENGTH_LONG).show();
        }
    }

    public void deleteItem(GroceryItems groceryItem){
        if(groceryItems.isEmpty())
            Toast.makeText(WelcomeActivity.this, "Shopping list is empty", Toast.LENGTH_LONG).show();
        else if(groceryItems.contains(groceryItem)) {
            groceryItems.remove(groceryItem);
            Toast.makeText(WelcomeActivity.this, groceryItem.getItemName()+ " removed from shopping list", Toast.LENGTH_LONG).show();
        }
        else
            Toast.makeText(WelcomeActivity.this, "There is no "+ groceryItem.getItemName() + " on your shopping list", Toast.LENGTH_LONG).show();
    }

}