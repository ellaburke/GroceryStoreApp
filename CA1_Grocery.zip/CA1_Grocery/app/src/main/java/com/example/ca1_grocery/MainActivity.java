package com.example.ca1_grocery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String hardcodedUsername = "Ellaburke99";
    String hardcodedPassword = "password";
    EditText userNameEditText;
    EditText passwordEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userNameEditText = (EditText) findViewById(R.id.userNameEditText);
        passwordEditText = (EditText) findViewById(R.id.passwordEditText);
        Button logInButton = (Button) findViewById(R.id.logInButton);


        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameInput = userNameEditText.getText().toString();
                String passwordInput = passwordEditText.getText().toString();
                if(usernameInput.equals(hardcodedUsername) && passwordInput.equals(hardcodedPassword)){
                    Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
                    EditText editText = (EditText)findViewById(R.id.userNameEditText);
                    intent.putExtra("usernameInput", usernameInput);
                    startActivity(intent);

                }
                else if(usernameInput.length() <6 & passwordInput.length() <6){
                    Toast.makeText(MainActivity.this, "Username & Password must be at least 6 characters, try again!", Toast.LENGTH_LONG).show();
                }
                else if(usernameInput.length() <6){
                    Toast.makeText(MainActivity.this, "Username must be at least 6 characters, try again!", Toast.LENGTH_LONG).show();
                }
                else if(passwordInput.length() <6){
                    Toast.makeText(MainActivity.this, "Password must be at least 6 characters, try again!", Toast.LENGTH_LONG).show();
                }
                else if(passwordInput.contains(" ")){
                    Toast.makeText(MainActivity.this, "Password must contain no spaces, try again!", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Incorrect Username or Password", Toast.LENGTH_LONG).show();
                }

            }
        });

    }
}